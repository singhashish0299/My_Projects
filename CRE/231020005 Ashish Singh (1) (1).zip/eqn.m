function DYDT = eqn(t,q)  

N=6.02*10^17; % Avogardo constant value
pch4=0.45*10^5; % initial pressure of qethane in pascal
vi=1*10^-3; % initial volume(m3)
qch4=pch4*vi/(8.314*973); %initial moles of methane
par=0.45*101325;% pressure of Ar in pascal
qar=par*vi/(8.314*973);%initial moles of Ar
pna=0.1*10^5;% pressure of sodium in pascal
qna=pna*vi/(8.314*973);%initial moles of sodium
qi=qch4+qar+qna %total initial moles
qf=q(1)+q(2)+q(3)+q(4)+q(5)+q(6)+q(7)+q(8)+q(9)+q(10)+q(11)+q(12)+q(13)+q(14)+q(15)+q(16)+qar;
% nt is total moles pctdashesent at any time t.
vf=qf*vi/qi % total volume at any time t since pressure is constant

kf=[1.1*10^-8 2.2*10^9 1.5*10^11 N*2.2*10^-21 N*3.2*10^-22 N*10^-23 N*9.4*10^-27 N*2.3*10^-23 N*3.1*10^-21 N*6.9*10^-13 N*9.9*10^-24 9.5*10^9 8.7*10^10 6.8*10^3 8.4*10^5 7.1*10^3 5*10^9 5.8*10^8 4.4*10^-1 1.4*10^8 2.4*10^1 4.7*10^6 N*1.9*10^-10 N*2.8*10^-10];

kb=[N*4.1*10^-10 N*1.5*10^-9  N*4.4*10^-9 N*1.9*10^-10 4.1*10^9 N*1.9*10^-12 N*6.6*10^-11 3.9*10^2 4.7*10^4 N*5.7*10^-15 N*3.8*10^-19 N*3.3*10^-9 N*7.3*10^-9 N*3*10^-9  N*2.3*10^-10 N*1.4*10^-9 N*1.5*10^-9 N*3.1*10^-9 N*3.7*10^-12 N*5.1*10^-10 N*5*10^-10 N*3.9*10^-11 1.8*10^-10 2.7*10^-4];


%{
ri for each species is defined as d(mole of species)/dt 
x1=ch4 
x2=ch3* 
x3=h* 
x4=Na2 
x5=Na 
x6=Na3   
x7=NaH 
x8=HNaCh3 
x9=Na2H 
x10=Na2Ch3 
x11=HNa2Ch3 
x12=HNa3Ch3 
x13=h2 
x14=C2H6 
x15=NaCh3 
x16=Na3H 
%}

x1= kf(1)*(q(1)/vf) - kb(1)*(q(2)/vf)*(q(3)/vf)

x2= kf(2)*(q(4)/vf) - kb(2)*(q(5)/vf)

x3= kf(3)*(q(6)/vf)  - kb(3)*(q(4)/vf)*(q(5)/vf)

x4=  kf(4)*(q(1)/vf)*(q(5)/vf) - kb(4)*(q(7)/vf)*(q(2)/vf)

x5= kf(5)*(q(5)/vf)*(q(1)/vf) - kb(5)*(q(8)/vf)

x6= kf(6)*(q(4)/vf)*(q(1)/vf) - kb(6)*(q(9)/vf)*(q(2)/vf)

x7= kf(7)*(q(1)/vf)*(q(4)/vf) - kb(7)*(q(10)/vf)*(q(3)/vf)

x8= kf(8)*(q(1)/vf)*(q(4)/vf)  - kb(8)*(q(11)/vf)

x9= kf(9)*(q(1)/vf)*(q(6)/vf) - kb(9)*(q(12)/vf)

x10=  kf(10)*(q(1)/vf)*(q(3)/vf)  - kb(10)*(q(2)/vf)*(q(13)/vf)

x11=  kf(11)*(q(1)/vf)*(q(2)/vf) - kb(11)*(q(14)/vf)*(q(3)/vf)

x12= kf(12)*(q(8)/vf) - kb(12)*(q(15)/vf)*(q(3)/vf)

x13= kf(13)*(q(8)/vf) - kb(13)*(q(2)/vf)*(q(7)/vf)

x14=  kf(14)*(q(7)/vf) - kb(14)*(q(3)/vf)*(q(5)/vf)

x15=  kf(15)*(q(15)/vf) - kb(15)*(q(2)/vf)*(q(5)/vf)

x16=  kf(16)*(q(9)/vf) - kb(16)*(q(4)/vf)*(q(3)/vf)

x17= kf(17)*(q(9)/vf) - kb(17)*(q(5)/vf)*(q(7)/vf)

x18= kf(18)*(q(10)/vf)  - kb(18)*(q(4)/vf)*(q(2)/vf)

x19= kf(19)*(q(10)/vf)  - kb(19)*(q(5)/vf)*(q(15)/vf)

x20= kf(20)*(q(16)/vf)  - kb(20)*(q(4)/vf)*(q(7)/vf)

x21=kf(21)*(q(16)/vf)  - kb(21)*(q(6)/vf)*(q(3)/vf)

x22= kf(22)*(q(16)/vf)  - kb(22)*(q(5)/vf)*(q(9)/vf)

x23= kf(23)*(q(3)/vf)*(q(3)/vf) - kb(23)*(q(13)/vf)

x24= kf(24)*(q(2)/vf)*(q(2)/vf) - kb(24)*(q(14)/vf)

r1= - vf*(x1+x4+x5+x6+x7+x8+x9+x10+x11)

r2= vf*(x1+x4+x6+x10-x11+x13+x15+x18-2*x24)

r3= vf*(x1+x7-x10+x11+x12+x14+x16+x21-2*x23)

r4=vf*(-x2+x3-x6-x7-x8+x16+x18+x20)

r5=vf*(2*x2+x3-x4-x5+x14+x15+x17+x19+x22)

r6=vf*(-x3-x9+x21)

r7=vf*(x4+x13-x14+x17+x20)

r8=vf*(x5-x12-x13)

r9=vf*(x6-x16-x17+x22)

r10=vf*(x7-x18-x19)

r11=vf*(x8)

r12=vf*(x9)

r13=vf*(x10+x23)

r14=vf*(x11+x24)

r15=vf*(x12-x15+x19)

r16=vf*(-x20-x21-x22)

DYDT =[r1; r2; r3; r4; r5; r6; r7; r8; r9; r10; r11; r12; r13; r14; r15; r16]

end








