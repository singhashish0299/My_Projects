
t=(0:1:7200); %seconds
N=6.02*10^23*10^-6; %Avogadro constant multiplied 
pch4=0.45*101325; %pressure of methane in pascal
vi=1*10^-3; %m^3, initial volume
qch4=pch4*vi/(8.314*973); %initial moles of methane
par=0.45*101325;%pressure of argon in pascal
qar=par*vi/(8.314*973);%initial moles of argon
pna=0.1*101325;%pressure of sodium in pascal
qna=pna*vi/(8.314*973);%initial moles of sodium
qi=qch4+qar+qna; %total initial moles
IN=[qch4 0 0 0 qna 0 0 0 0 0 0 0 0 0 0 0];
[t,q]=ode15s(@eqn,t,IN)
plot(t,q(:,1));
xlabel('time(sec)');
ylabel('moles of CH4');
title('Micro Kinetics MOdelling of CH4');